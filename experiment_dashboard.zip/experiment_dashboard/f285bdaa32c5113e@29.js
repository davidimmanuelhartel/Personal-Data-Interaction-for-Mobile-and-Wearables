function _1(md){return(
md`# Dashboard Subject 11`
)}

function _stress_dataset(FileAttachment){return(
FileAttachment("0_subject_11@1.csv").csv({type: true})
)}

function _stress_activities(FileAttachment){return(
FileAttachment("0_subject_11_activities@1.csv").csv({type: true})
)}

function _4(md){return(
md`Here you can see the evolution of your stress level based on the data collected during this week. **When you hover over each bar, you will see the activities registered on that day of the week**. It can take some seconds for the activities to appear once you place your mouse over the bar. You can select a time window in the upper graph by using your mouse. `
)}

function _5(vl,stress_dataset)
{
  const brush = vl.selectInterval().encodings('x').resolve('intersect'); // limit selection to x-axis (year) values
  const color = vl.color().average("Stress Score").scale({ domain:[0, 4],  scheme: ['#a83432', '#e88010', '#ffdd1f', '#71d111', '#71d111'], reverse: true });
  vl.selectInterval().encodings('x').resolve('intersect')
  // dynamic query histogram
  const days = vl.markLine({ interpolate: "basis", color: "black"})
    .data(stress_dataset)
    .params(brush)
    .encode(
    vl.y().average("Stress Score").title(null).scale({domain:[0.5, 4.5]}).axis({labelExpr: "datum.label == 0.5 ? ' ' : datum.label == 1 ? 'No Stress':  datum.label == 2 ? 'Low' : datum.label == 3 ?'Moderate' : datum.label == 4 ? 'High' : '' ", labelFlush: false,  values:[1, 2, 3, 4]}),
    vl.x().fieldO("Date").timeUnit('datemonth').title("Date")
    )
    .width(800)
    .height(200)
    .title({text:"Evolution of your Stress Level", align: "center", fontSize:18, "offset": 20})
    
    ;
  const bar = vl.markBar() // Make a bar chart
  .data(stress_dataset)               // Using the alphabet data
  .transform(vl.filter(brush))
  .encode(
    vl.x().fieldN("Date").timeUnit("day").title('Weekday').sort(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]).axis({domain: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], values: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]})
, // .sort(vl.fieldQ("frequency").order("descending")), // Letters are ordinal on the x-axis
    vl.y().average("Stress Score").title(null).scale({domain:[0.5, 4.5]}).axis({labelExpr: "datum.label == 0.5 ? ' ' : datum.label == 1 ? 'No Stress':  datum.label == 2 ? 'Low' : datum.label == 3 ?'Moderate' : datum.label == 4 ? 'High' : '' ", labelFlush: false,  values:[1, 2, 3, 4]}),
    vl.color().average('Stress Score').scale({domain: [1,4], scheme: ['#a83432', '#e88010', '#ffdd1f', '#71d111'], reverse: true}).title('Stress Score').legend(
    {orient: 'none',direction: 'vertical', legendX: 818, legendY: 250,
      labelExpr: "datum.label == 0.5 ? ' ' : datum.label == 1 ? 'No Stress':  datum.label == 2 ? 'Low' : datum.label == 3 ?'Moderate' : datum.label == 4 ? 'High' : '' "
    },),
    vl.tooltip([vl.fieldN('Social'), vl.fieldN('Health'), vl.fieldN('Hobbies'), vl.fieldN('Studies'), vl.fieldN('Work')]),
)
  .width(800)
  .height(400)
  
  
  return vl.vconcat(days, bar).spacing(30).render();
  
}


function _6(md){return(
md`You can see how often you did different activities throughout the course of the week in the graph below, as well as the average stress level connected with each activity. The average stress level associated to a specific activity may be more accurate when analyzed in the long term.`
)}

function _7(vl,stress_activities)
{
  
const bar = vl.markBar() // Make a bar chart
  .data(stress_activities)               // Using the alphabet data
  .encode(
    vl.x().fieldN('Activity').sort({
        op: "count",
        order: "descending"
      })
, // .sort(vl.fieldQ("frequency").order("descending")), // Letters are ordinal on the x-axis
    vl.y().count().scale({ domain:[0, 7]}).axis({values:[0, 1, 2, 3, 4, 5, 6, 7]}),
    vl.color({type:'nominal'}).average('Stress Score').scale({domain: [1, 4], scheme: ['#a83432', '#e88010', '#ffdd1f', '#71d111'], reverse: true}).title('Stress Score').legend(
    {
      labelExpr: "datum.label == 1 ? 'No Stress':  datum.label == 2 ? 'Low' : datum.label == 3 ?'Moderate' : datum.label == 4 ? 'High' : '' "
    },)
)
  .width(800)
  .height(400)
  .title({text:"Summary of registered Activities", fontSize:18, "offset": 20})
  
  
  return vl.vconcat(bar).spacing(30).render();
  
}


export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["0_subject_11@1.csv", {url: new URL("./files/8c477121953c18ff9826cf58fe6347fb06098554ab5b77a8852a8bb3da650160697a7ce4661da0dfb8cb1c47d048f74155114ec2bd21371c3f5a713513926deb", import.meta.url), mimeType: "text/csv", toString}],
    ["0_subject_11_activities@1.csv", {url: new URL("./files/8e9e54b12111fe6279f12a3c8ceba7e306fd7c5652bb5635372d4dc2b95dad1141836a1c886886d52e01ba74bfc50c9752569f7153b7b367274f449e02d5394a", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("stress_dataset")).define("stress_dataset", ["FileAttachment"], _stress_dataset);
  main.variable(observer("stress_activities")).define("stress_activities", ["FileAttachment"], _stress_activities);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer()).define(["vl","stress_dataset"], _5);
  main.variable(observer()).define(["md"], _6);
  main.variable(observer()).define(["vl","stress_activities"], _7);
  return main;
}
